#repartition-des-groupes
ce script prend un fichier texte et un nombre maximum de personnes saisi par l'utilisateur et crée un fichier "groupes.txt" qui contient une listes
des groupes avec une répartition équilibrée du nombre de personnes par groupe sans dépasser le nombre maximal des personnes par groupe et un fichier
"logs.txt" qui affiche l'historique des étapes faites par le script."# repartition-des-groupes" 
# repartition-des-groupes
